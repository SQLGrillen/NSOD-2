/*============================================================================
File: 0060 - sp_executesql.sql

Summary: This script demonstrates the use of sp_executesql

THIS SCRIPT IS PART OF THE TRACK:
"Why you don't testqueries with variables"

Date: March 2021

SQL Server Version: 2016 / 2017 / 2019
------------------------------------------------------------------------------
Written by Nina Weisheidinger, Devoteam Alegri GmbH


This script is intended only as a supplement to demos and lectures
given by Nina Weisheidinger.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
============================================================================*/

USE demo_db;
GO

/*Preperation START*/
--To make sure that we have a clean playground
DROP TABLE IF EXISTS dbo.messages;
GO

-- Create the demo table for @variable tests
SELECT	*
INTO	dbo.messages
FROM	sys.messages;
GO

-- Create index 
CREATE NONCLUSTERED INDEX x1 ON dbo.messages (severity);
GO

/*Preperation END*/

/*Demo*/

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 12
DECLARE @stmt NVARCHAR(1000) = N'SELECT 
									  [message_id]
									, [language_id]
									, [severity]
									, [is_event_logged]
									, [text] 
								FROM dbo.messages
								WHERE	severity = @severity
								ORDER BY 
									  language_id
									, message_id;' 
DECLARE @vars NVARCHAR(64) = N'@severity TINYINT';
 
EXEC sp_executesql @stmt, @vars, @severity;
GO

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 16
DECLARE @stmt NVARCHAR(1000) = N'SELECT 
									  [message_id]
									, [language_id]
									, [severity]
									, [is_event_logged]
									, [text] 
								FROM dbo.messages
								WHERE	severity = @severity
								ORDER BY 
									  language_id
									, message_id;' 
DECLARE @vars NVARCHAR(64) = N'@severity TINYINT';
 
EXEC sp_executesql @stmt, @vars, @severity;
GO

ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE; 
GO

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 16
DECLARE @stmt NVARCHAR(1000) = N'SELECT 
									  [message_id]
									, [language_id]
									, [severity]
									, [is_event_logged]
									, [text] 
								FROM dbo.messages
								WHERE	severity = @severity
								ORDER BY 
									 language_id
									,message_id;' 
DECLARE @vars NVARCHAR(64) = N'@severity TINYINT';
 
EXEC sp_executesql @stmt, @vars, @severity;
GO

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 12
DECLARE @stmt NVARCHAR(1000) = N'SELECT 
									  [message_id]
									, [language_id]
									, [severity]
									, [is_event_logged]
									, [text] 
								FROM dbo.messages
								WHERE	severity = @severity
								ORDER BY 
									 language_id
									,message_id;'
DECLARE @vars NVARCHAR(64) = N'@severity TINYINT';
 
EXEC sp_executesql @stmt, @vars, @severity;
GO

--To make sure that we have a clean playground again
DROP TABLE IF EXISTS dbo.messages;
GO
