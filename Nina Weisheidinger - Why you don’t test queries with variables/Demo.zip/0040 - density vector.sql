/*============================================================================
File: 0040 - density vector.sql

Summary: This script shows basic statistics

THIS SCRIPT IS PART OF THE TRACK:
"Why you don't testqueries with variables"

Date: March 2021

SQL Server Version: 2016 / 2017 / 2019
------------------------------------------------------------------------------
Written by Nina Weisheidinger, Devoteam Alegri GmbH


This script is intended only as a supplement to demos and lectures
given by Nina Weisheidinger.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
============================================================================*/

USE demo_db;
GO

/*Preperation START - NOT NEEDED*/
--To make sure that we have a clean playground
DROP TABLE IF EXISTS dbo.messages;
GO

-- Create the demo table for @variable tests
SELECT	*
INTO	dbo.messages
FROM	sys.messages;
GO

-- Create index 
CREATE NONCLUSTERED INDEX x1 ON dbo.messages (severity);
GO
/*Preperation END*/

-- typical developer behaviour
-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 12;

SELECT * FROM dbo.messages
WHERE severity = @severity
ORDER BY 
	 language_id
	,message_id;

-- Why are these weird numbers?
-- See the distribution of data
DBCC SHOW_STATISTICS (N'dbo.messages', N'x1');
GO

-- How the density vector is calculated?
-- 1/distinct values in the severity column (Steps)
SELECT 1/16.0 AS densityVector

-- Calculate the average data Distribution
-- densityVector * Total number of rows in the messages table
SELECT (1/16.0) * 309540 AS avgDistribution

--19346.250000

--clear Plan Cache
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE; 

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 12;

SELECT * FROM dbo.messages
WHERE severity = @severity
ORDER BY 
	 language_id
	,message_id;
GO

--clear Plan Cache
ALTER DATABASE SCOPED CONFIGURATION CLEAR PROCEDURE_CACHE; 

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 16;

SELECT * FROM dbo.messages
WHERE severity = @severity
ORDER BY 
	 language_id
	,message_id;
GO

/* a wrong estimate leads to higher resource allocation */

/*
	If the data is not skewed the usage of variables is o.k.
	The following skript will add more data into the table
	for an even distribution of data
*/

DECLARE @s TINYINT = 0;
DECLARE @num_rows INT = 0;
WHILE @s <= 24
BEGIN
	SELECT	@num_rows = COUNT_BIG(*)
	FROM	dbo.messages
	WHERE	severity = @s;

	IF @num_rows <> 0
	BEGIN
		SET	@num_rows = 250000 - @num_rows;

		IF @num_rows > 0
			INSERT INTO dbo.messages WITH (TABLOCK)
				(
					message_id,
					language_id,
					severity,
					is_event_logged,
					text
				)
			SELECT TOP (@num_rows)
					message_id,
					language_id,
					@s,
					is_event_logged,
					text
			FROM	dbo.messages
			ORDER BY
					NEWID();
	END

	SET @s += 1;
END
GO

UPDATE STATISTICS dbo.messages (x1) WITH FULLSCAN;
GO

DBCC SHOW_STATISTICS(N'dbo.messages', N'x1');
GO

/*
	Now the usage of variables is harmless because the 
	distribution of data is the same over all
	distinct values
*/

-- run the following query with activated execution plan!
-- and check the estimated num of rows!
DECLARE @severity TINYINT = 12

SELECT 
	  [message_id]
	, [language_id]
	, [severity]
	, [is_event_logged]
	, [text] 
FROM dbo.messages
WHERE	severity = @severity
ORDER BY 
	 language_id
	,message_id;
GO

--To make sure that we have a clean playground again
DROP TABLE IF EXISTS dbo.messages;
GO
