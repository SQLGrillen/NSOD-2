/*============================================================================
File: 0020 - query parsing.sql

Summary: This script demonstrates parse only

THIS SCRIPT IS PART OF THE TRACK:
"Why you don't testqueries with variables"

Date: March 2021

SQL Server Version: 2016 / 2017 / 2019
------------------------------------------------------------------------------
Written by Nina Weisheidinger, Devoteam Alegri GmbH


This script is intended only as a supplement to demos and lectures
given by Nina Weisheidinger.

THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED
TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
============================================================================*/

USE demo_db;
GO

/*Preperation START - NOT NEEDED*/
--To make sure that we have a clean playground
DROP TABLE IF EXISTS dbo.messages;
GO

-- Create the demo table for @variable tests
SELECT	*
INTO	dbo.messages
FROM	sys.messages;
GO
/*Preperation END*/

/*Demo*/
SELECT * 
FROM dbo.messages
WHERE severity = 12;
GO

SET PARSEONLY ON;
GO
SELECT * 
FROM dbo.messages
WHERE severity = 12;
GO

--To make sure that we have a clean playground
DROP TABLE IF EXISTS dbo.messages;
GO
