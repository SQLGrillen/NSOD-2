using System;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Security.Cryptography;
using System.Collections.Generic;
using System.Text;

public partial class UserDefinedFunctions
{
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true, DataAccess = DataAccessKind.None, SystemDataAccess = SystemDataAccessKind.None)]
    public static SqlString GetHashID(SqlString Input1)
    {
        string HashID = String.Empty;
        SHA256Managed crypt = new SHA256Managed();
        byte[] crypto = crypt.ComputeHash(Encoding.Unicode.GetBytes(Input1.ToString()));
        foreach (byte singlebyte in crypto)
        {
            HashID += String.Format("{0:x2}", singlebyte);
        }

        return HashID.ToUpper();
    }
}
